<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- title -->
    <title><?= $title ?> - Mlejit Coffee Shop</title>

    <?php if (isset($style)) $this->load->view($style); ?>

</head>

<body>

    <main>
        <div class="container">

            <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

                            <div class="d-flex justify-content-center">
                                <a href="index.html" class="d-flex align-items-center w-auto">
                                    <img src="<?= base_url(); ?>assets/img/logo_mlejit_crop.png" alt="" width="175px">
                                    <!-- <span class="d-none d-lg-block">mlejit kopi</span> -->
                                </a>
                            </div>
                            <!-- End Logo -->

                            <?php if (isset($pages)) $this->load->view($pages); ?>

                            <div class="credits">
                                <!-- All the links in the footer should remain intact. -->
                                <!-- You can delete the links only if you purchased the pro version. -->
                                <!-- Licensing information: https://bootstrapmade.com/license/ -->
                                <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
                                <!-- Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> -->
                            </div>

                        </div>
                    </div>
                </div>

            </section>

        </div>
    </main><!-- End #main -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <?php if (isset($script)) $this->load->view($script); ?>

</body>

</html>