<!-- Vendor JS Files -->
<script src="<?= base_url(); ?>assets/dashboard/vendor/apexcharts/apexcharts.min.js"></script>
<script src="<?= base_url(); ?>assets/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/dashboard/vendor/chart.js/chart.umd.js"></script>
<script src="<?= base_url(); ?>assets/dashboard/vendor/echarts/echarts.min.js"></script>
<script src="<?= base_url(); ?>assets/dashboard/vendor/quill/quill.min.js"></script>
<script src="<?= base_url(); ?>assets/dashboard/vendor/simple-datatables/simple-datatables.js"></script>
<script src="<?= base_url(); ?>assets/dashboard/vendor/tinymce/tinymce.min.js"></script>
<script src="<?= base_url(); ?>assets/dashboard/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="<?= base_url(); ?>assets/dashboard/js/main.js"></script>


<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script src="<?= base_url() ?>assets/dashboard/js/sweetalert2/sweetalert2.all.min.js"></script>

<script src="<?= base_url() ?>assets/dashboard/js/script.js"></script>